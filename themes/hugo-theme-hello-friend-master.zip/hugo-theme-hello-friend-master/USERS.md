# Meet the users of Hello Friend theme!

<!--
TEMPLATE:

- https://radoslawkoziel.pl — **Radek Kozieł** (Software designer and developer)

-->

- https://0x44.pw — **Ian Pringle** (System Admin and developer)
- https://blog.agung.io - **Agung Pratama** (Software Engineer and DevOps)
- https://protocod.gitlab.io/blog/ **protocod** (Web Developer)
- https://arubacao.com **Christopher Lass** (Software Engineer and DevOps)
- https://mfaishal.com **Faishal Irawan** (Student)
- https://musq.github.io — **Ashish Ranjan** (Software Engineer)
- https://fazi1058.github.io **Faezeh Roeinfard** (Student)
- https://www.gabrielacaesar.com/ - **Gabriela Caesar** (Data journalist)
- https://verso.re/ - **Joan Calabrés** (Security Engineer)
- https://blog.lepape.me/ - **François Le Pape** (Student & developer freelance)
- https://blog.jyny.dev/ - **Jyny Chen** (Software Engineer)
- https://felixleger.com/ - **Félix Léger** (Sofware Developer and DevOps)
- https://cobalto.net/ - **Daniel Pessoa** (Sofware Developer and BI Analyst)
- https://www.imgalone.com/ - **Iancu makes games alone** (Indie Game Dev)
- https://jonathan.rico.live/ - **Jonathan Rico** (Electronics Engineer)
- https://mritd.com/ - **漠然** (Software Engineer and DevOps)
- https://ilya-lesikov.com - **Ilya Lesikov** (DevOps, SRE)
- https://www.adamormsby.com - **Adam Ormsby** (Generalist Programmer - Web, Mobile, Games)
